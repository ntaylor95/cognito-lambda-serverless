var consts = {
    test: "this is a test",
    prefix: "nicole-"
}

module.exports = consts;