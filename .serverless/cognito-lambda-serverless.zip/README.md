# cognito-lambda-serverless
serverless and cognito with a react page for signing in and calling to an API
